package com.example.notesapp.utilities

//define all the constants here that are using inside our app
const val DATABASE_NAME = "notes_database"